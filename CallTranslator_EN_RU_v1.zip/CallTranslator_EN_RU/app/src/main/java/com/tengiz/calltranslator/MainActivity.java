package com.tengiz.calltranslator;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.mlkit.common.model.DownloadConditions;
import com.google.mlkit.nl.translate.TranslateLanguage;
import com.google.mlkit.nl.translate.Translation;
import com.google.mlkit.nl.translate.Translator;
import com.google.mlkit.nl.translate.TranslatorOptions;

import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends AppCompatActivity implements RecognitionListener {

    private static final int AUDIO_PERMISSION_REQUEST = 1001;

    private TextView statusText;
    private TextView englishText;
    private TextView russianText;
    private Button startStopButton;

    private SpeechRecognizer speechRecognizer;
    private Intent speechIntent;
    private Translator translator;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private boolean modelReady = false;
    private boolean listening = false;
    private boolean destroyed = false;
    private String lastPartial = "";
    private Runnable pendingPartialTranslation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        statusText = findViewById(R.id.statusText);
        englishText = findViewById(R.id.englishText);
        russianText = findViewById(R.id.russianText);
        startStopButton = findViewById(R.id.startStopButton);
        Button clearButton = findViewById(R.id.clearButton);

        startStopButton.setOnClickListener(v -> {
            if (listening) {
                stopListening();
            } else {
                ensurePermissionAndStart();
            }
        });

        clearButton.setOnClickListener(v -> {
            englishText.setText(R.string.waiting_english);
            russianText.setText(R.string.waiting_russian);
            lastPartial = "";
        });

        setupTranslator();
        setupSpeechRecognizer();
    }

    private void setupTranslator() {
        TranslatorOptions options = new TranslatorOptions.Builder()
                .setSourceLanguage(TranslateLanguage.ENGLISH)
                .setTargetLanguage(TranslateLanguage.RUSSIAN)
                .build();

        translator = Translation.getClient(options);
        DownloadConditions conditions = new DownloadConditions.Builder().build();

        statusText.setText("Загрузка модели английский → русский… При первом запуске нужен интернет.");
        translator.downloadModelIfNeeded(conditions)
                .addOnSuccessListener(unused -> {
                    modelReady = true;
                    startStopButton.setEnabled(true);
                    statusText.setText(R.string.status_ready);
                })
                .addOnFailureListener(e -> {
                    modelReady = false;
                    startStopButton.setEnabled(false);
                    statusText.setText("Не удалось загрузить модель перевода. Проверьте интернет и перезапустите приложение.");
                });
    }

    private void setupSpeechRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            statusText.setText("На этом телефоне не найден сервис распознавания речи.");
            return;
        }

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
        speechRecognizer.setRecognitionListener(this);

        speechIntent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        speechIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        speechIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US");
        speechIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "en-US");
        speechIntent.putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, "en-US");
        speechIntent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        speechIntent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);
        speechIntent.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, false);
    }

    private void ensurePermissionAndStart() {
        if (!modelReady) {
            statusText.setText("Модель перевода ещё загружается…");
            return;
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.RECORD_AUDIO},
                    AUDIO_PERMISSION_REQUEST);
            return;
        }

        startListening();
    }

    private void startListening() {
        if (speechRecognizer == null || destroyed) return;
        listening = true;
        startStopButton.setText(R.string.stop);
        statusText.setText(R.string.status_listening);

        handler.removeCallbacksAndMessages(null);
        try {
            speechRecognizer.startListening(speechIntent);
        } catch (Exception e) {
            statusText.setText("Не удалось запустить микрофон: " + safeMessage(e));
            listening = false;
            startStopButton.setText(R.string.start);
        }
    }

    private void restartListeningSoon(long delayMs) {
        if (!listening || destroyed) return;
        handler.postDelayed(() -> {
            if (!listening || destroyed || speechRecognizer == null) return;
            try {
                speechRecognizer.startListening(speechIntent);
            } catch (Exception e) {
                statusText.setText("Микрофон недоступен. Возможно, его использует телефонный звонок.");
            }
        }, delayMs);
    }

    private void stopListening() {
        listening = false;
        handler.removeCallbacksAndMessages(null);
        if (speechRecognizer != null) {
            try {
                speechRecognizer.stopListening();
                speechRecognizer.cancel();
            } catch (Exception ignored) {
            }
        }
        startStopButton.setText(R.string.start);
        statusText.setText(R.string.status_stopped);
    }

    private void translateText(String text, boolean finalResult) {
        if (!modelReady || text == null || text.trim().isEmpty()) return;
        final String clean = text.trim();

        translator.translate(clean)
                .addOnSuccessListener(translated -> {
                    if (destroyed) return;
                    englishText.setText(clean);
                    russianText.setText(translated);
                    if (finalResult && listening) {
                        statusText.setText("Переведено. Продолжаю слушать…");
                    }
                })
                .addOnFailureListener(e -> statusText.setText("Ошибка перевода: " + safeMessage(e)));
    }

    private void debouncePartialTranslation(String text) {
        if (text == null || text.trim().isEmpty()) return;
        String clean = text.trim();
        if (clean.equals(lastPartial)) return;
        lastPartial = clean;
        englishText.setText(clean);

        if (pendingPartialTranslation != null) {
            handler.removeCallbacks(pendingPartialTranslation);
        }

        pendingPartialTranslation = () -> translateText(clean, false);
        handler.postDelayed(pendingPartialTranslation, 350);
    }

    private String safeMessage(Exception e) {
        String msg = e.getMessage();
        return msg == null || msg.trim().isEmpty() ? "неизвестная ошибка" : msg;
    }

    @Override
    public void onReadyForSpeech(Bundle params) {
        if (listening) statusText.setText("Говорите по-английски — я слушаю…");
    }

    @Override
    public void onBeginningOfSpeech() {
        if (listening) statusText.setText("Распознаю речь…");
    }

    @Override
    public void onRmsChanged(float rmsdB) {
        // No UI update needed.
    }

    @Override
    public void onBufferReceived(byte[] buffer) {
        // Not used.
    }

    @Override
    public void onEndOfSpeech() {
        if (listening) statusText.setText("Обрабатываю фразу…");
    }

    @Override
    public void onError(int error) {
        if (!listening) return;

        String message;
        long retryDelay = 700;
        switch (error) {
            case SpeechRecognizer.ERROR_AUDIO:
                message = "Ошибка микрофона. Во время обычного звонка Android может блокировать доступ к звуку.";
                retryDelay = 1500;
                break;
            case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS:
                message = "Нет разрешения на микрофон.";
                listening = false;
                startStopButton.setText(R.string.start);
                break;
            case SpeechRecognizer.ERROR_NETWORK:
            case SpeechRecognizer.ERROR_NETWORK_TIMEOUT:
                message = "Ошибка распознавания через сеть. Проверьте интернет.";
                retryDelay = 1500;
                break;
            case SpeechRecognizer.ERROR_NO_MATCH:
                message = "Речь не распознана. Продолжаю слушать…";
                break;
            case SpeechRecognizer.ERROR_RECOGNIZER_BUSY:
                message = "Распознавание занято. Повторяю…";
                retryDelay = 1200;
                break;
            case SpeechRecognizer.ERROR_SPEECH_TIMEOUT:
                message = "Жду английскую речь…";
                break;
            default:
                message = "Распознавание прервалось (код " + error + "). Повторяю…";
                retryDelay = 1000;
        }
        statusText.setText(message);
        if (listening) restartListeningSoon(retryDelay);
    }

    @Override
    public void onResults(Bundle results) {
        ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        if (matches != null && !matches.isEmpty()) {
            lastPartial = "";
            translateText(matches.get(0), true);
        }
        restartListeningSoon(450);
    }

    @Override
    public void onPartialResults(Bundle partialResults) {
        ArrayList<String> matches = partialResults.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        if (matches != null && !matches.isEmpty()) {
            debouncePartialTranslation(matches.get(0));
        }
    }

    @Override
    public void onEvent(int eventType, Bundle params) {
        // Not used.
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == AUDIO_PERMISSION_REQUEST) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startListening();
            } else {
                statusText.setText("Без разрешения на микрофон приложение не сможет распознавать речь.");
            }
        }
    }

    @Override
    protected void onDestroy() {
        destroyed = true;
        listening = false;
        handler.removeCallbacksAndMessages(null);

        if (speechRecognizer != null) {
            speechRecognizer.destroy();
            speechRecognizer = null;
        }
        if (translator != null) {
            translator.close();
        }
        super.onDestroy();
    }
}
